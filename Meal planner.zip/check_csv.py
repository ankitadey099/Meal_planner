import pandas as pd

df = pd.read_csv("data/recipes.csv")
print("CSV Columns:", df.columns.tolist())
